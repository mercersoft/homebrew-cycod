public static class ChatHistoryDefaults
{
    public const bool UseOpenAIFormat = true;
}
