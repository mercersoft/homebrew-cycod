public class Colors
{
    public Colors(ConsoleColor foreground, ConsoleColor background)
    {
        Foreground = foreground;
        Background = background;
    }

    public ConsoleColor Foreground;
    public ConsoleColor Background;
}