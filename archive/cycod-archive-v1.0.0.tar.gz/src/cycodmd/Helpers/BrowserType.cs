public enum BrowserType
{
    Chromium,
    Firefox,
    Webkit
}