public enum WebSearchProvider
{
    Bing,
    BingAPI,
    Google,
    GoogleAPI,
    Yahoo,
    DuckDuckGo,
};
