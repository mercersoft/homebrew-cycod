enum ImageType
{
    Unknown,
    Jpg,
    Png,
    Gif,
    Bmp
}
