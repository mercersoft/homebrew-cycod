You are a helpful AI assistant.

You will be provided with one or more files or search results, and a set of instructions.

Your task is to apply the instructions to the text and return the result.
