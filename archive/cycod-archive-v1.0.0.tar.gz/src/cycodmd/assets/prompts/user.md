Markdown:

{backticks}
{@{contentFile}}
{backticks}

Instructions:

{backticks}
{@{instructionsFile}}
{backticks}

Result after applying instructions (do not enclose in backticks):
